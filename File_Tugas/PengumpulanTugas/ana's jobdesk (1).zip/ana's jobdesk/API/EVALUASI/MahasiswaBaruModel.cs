﻿namespace PKKMB_API.Model
{
	public class MahasiswaBaruModel
	{
		public string mhs_nopendaftaran { get; set; }
		public string mhs_namalengkap { get; set; }
		public string mhs_gender { get; set; }
		public string mhs_programstudi { get; set; }
		public string mhs_alamat { get; set; }
		public string mhs_notelepon { get; set; }
		public string mhs_email { get; set; }
		public string mhs_password { get; set; }
		public string mhs_kategori { get; set; }
		public string mhs_idkelompok { get; set; }
		public string mhs_idpkkmb { get; set; }
		public string mhs_statuskelulusan { get; set; }
		public string mhs_status { get; set; }
		public string mhs_saran { get; set; }
		public string mhs_kritik { get; set; }
		public string mhs_insight { get; set; }
		public string mhs_tglkirimevaluasi { get; set; }
	}
}
