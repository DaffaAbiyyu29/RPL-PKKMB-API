﻿using Microsoft.AspNetCore.Mvc;
using PKKMB_API.Model;

namespace PKKMB_API.Controllers
{
	[ApiController]
	[Route("[controller]")]
	public class AbsensiController : Controller
	{
		private readonly AbsensiRepository _absenRepo;
		ResponseModel response = new ResponseModel();

		public AbsensiController(IConfiguration configuration)
		{
			_absenRepo = new AbsensiRepository(configuration);
		}

		[HttpGet("/GetAllAbsensi", Name = "GetAllAbsensi")]
		public IActionResult GetAllAbsensi()
		{
			try
			{
				response.status = 200;
				response.messages = "Berhasil";
				response.data = _absenRepo.getAllData();
			}
			catch (Exception ex)
			{
				response.status = 500;
				response.messages = "Gagal";
			}
			return Ok(response);
		}

		[HttpGet("/GetAbsensi", Name = "GetAbsensi")]
		public IActionResult GetAbsensi(string abs_idabsensi)
		{
			try
			{
				response.status = 200;
				response.messages = "Berhasil";
				response.data = _absenRepo.getData(abs_idabsensi);
			}
			catch (Exception ex)
			{
				response.status = 500;
				response.messages = "Gagal, " + ex.Message;
			}
			return Ok(response);
		}

		[HttpPost("/TambahAbsensi", Name = "TambahAbsensi")]
		public IActionResult TambahAbsensi([FromBody] AbsensiModel absensi)
		{
			try
			{
				response.status = 200;
				response.messages = "Berhasil";
				_absenRepo.tambahAbsensi(absensi);
			}
			catch (Exception ex)
			{
				response.status = 500;
				response.messages = "Gagal, " + ex.Message;
			}
			return Ok(response);
		}
	}
}