﻿using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;

namespace PKKMB_API.Model
{
	public class AbsensiRepository
	{
		private readonly string _connectingString;
		private readonly SqlConnection _connection;
		ResponseModel response = new ResponseModel();
		private readonly IConfiguration _configuration;

		public AbsensiRepository(IConfiguration configuration)
		{
			_connectingString = configuration.GetConnectionString("DefaultConnection");
			_connection = new SqlConnection(_connectingString);
			_configuration = configuration;
		}

		public List<AbsensiModel> getAllData()
		{
			List<AbsensiModel> absenList = new List<AbsensiModel>();
			try
			{
				string query = "Select * from pkm_trabsensi";
				SqlCommand command = new SqlCommand(query, _connection);
				_connection.Open();
				SqlDataReader reader = command.ExecuteReader();
				while (reader.Read())
				{
					AbsensiModel absensi = new AbsensiModel
					{
						abs_idabsensi = reader["abs_idabsensi"].ToString(),
						abs_nim = reader["abs_nim"].ToString(),
						abs_nopendaftaran = reader["abs_nopendaftaran"].ToString(),
						abs_tglkehadiran = DateTime.Parse(reader["abs_tglkehadiran"].ToString()),
						abs_statuskehadiran = reader["abs_Statuskehadiran"].ToString(),
						abs_keterangan = reader["abs_keterangan"].ToString(),
						abs_status = reader["abs_status"].ToString(),
					};
					absenList.Add(absensi);
				}
				reader.Close();
				_connection.Close();
				return absenList;
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error : " + ex.Message);
				return null;
			}
		}

		public AbsensiModel getData([FromBody] string abs_idabsensi)
		{
			AbsensiModel absensi = new AbsensiModel();
			try
			{
				string query = "select * from pkm_trabsensi where abs_idabsensi = @p1";
				SqlCommand command = new SqlCommand(query, _connection);
				command.Parameters.AddWithValue("@p1", abs_idabsensi);
				_connection.Open();
				SqlDataReader reader = command.ExecuteReader();

				if (reader.Read())
				{
					absensi = new AbsensiModel
					{
						abs_idabsensi = reader["abs_idabsensi"].ToString(),
						abs_nim = reader["abs_nim"].ToString(),
						abs_nopendaftaran = reader["abs_nopendaftaran"].ToString(),
						abs_tglkehadiran = DateTime.Parse(reader["abs_tglkehadiran"].ToString()),
						abs_statuskehadiran = reader["abs_Statuskehadiran"].ToString(),
						abs_keterangan = reader["abs_keterangan"].ToString(),
						abs_status = reader["abs_status"].ToString(),
					};

					reader.Close();
					_connection.Close();
					return absensi;
				}
				else
				{
					// User not found
					reader.Close();
					_connection.Close();
					return null;
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.Message);
				return null;
			}
		}

        public ResponseModel tambahAbsensi([FromBody] AbsensiModel absensi)
        {
            try
            {
                SqlCommand command = new SqlCommand("sp_TambahAbsensi", _connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@p_nim", absensi.abs_nim);
                command.Parameters.AddWithValue("@p_nopendaftaran", absensi.abs_nopendaftaran);
                command.Parameters.AddWithValue("@p_tglkehadiran", absensi.abs_tglkehadiran);
                command.Parameters.AddWithValue("@p_statuskehadiran", absensi.abs_statuskehadiran);
                command.Parameters.AddWithValue("@p_keterangan", absensi.abs_keterangan);
                command.Parameters.AddWithValue("@p_status", absensi.abs_status);

                _connection.Open();
                command.ExecuteNonQuery();
                _connection.Close();

                response.status = 200;
                response.messages = "Absensi berhasil ditambahkan";
                response.data = absensi;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                response.status = 500;
                response.messages = "Terjadi kesalahan saat menambahkan Absensi = " + ex.Message;
                response.data = null;
            }

            return response;
        }
    }
}
